#!/bin/bash

# ---
# AUDIT Script for Warning Banners
# Benchmarks:
#   - 1.6.2: Ensure /etc/motd is configured properly
#   - 1.6.3: Ensure remote login warning banner is configured properly
#
# Usage: ./audit.sh <output_file.json>
# ---

# 1. Check for output file argument
if [ "$#" -ne 1 ]; then
    echo "Usage: $0 <output_file.json>"
    exit 1
fi

OUTPUT_FILE="$1"
echo "Starting audit for Warning Banners... saving report to $OUTPUT_FILE"

# --- Define Files ---
MOTD_FILE="/etc/motd"
ISSUE_NET_FILE="/etc/issue.net"
SSHD_CONFIG="/etc/ssh/sshd_config"

# --- Variables for JSON Report ---
AUDIT_STATUS="Compliant"
declare -a settings

# --- Helper Function to Check File ---
# Usage: check_file "File Name" "/path/to/file" "check_content"
check_file() {
    local name=$1
    local file=$2
    local check_content=$3
    local status="Compliant"
    local owner
    local perms

    if [ ! -f "$file" ]; then
        status="Non-Compliant (File not found)"
        owner="N/A"
        perms="N/A"
    else
        owner=$(stat -c "%U:%G" "$file")
        perms=$(stat -c "%a" "$file")

        if [ "$owner" != "root:root" ]; then
            status="Non-Compliant (Owner is $owner)"
        fi

        if [ "$perms" != "644" ]; then
            # We also accept stricter, but 644 is the standard
            status="Non-Compliant (Perms are $perms)"
        fi
        
        if [ "$check_content" == "true" ] && [ ! -s "$file" ]; then
            status="Non-Compliant (File is empty)"
        fi
    fi
    
    # Add to our JSON array
    settings+=("{\"file\": \"$file\", \"name\": \"$name\", \"status\": \"$status\", \"owner\": \"$owner\", \"permissions\": \"$perms\"}")
    
    # Update overall status
    if [[ "$status" == "Non-Compliant"* ]]; then
        AUDIT_STATUS="Non-Compliant"
    fi
}

# --- Audit 1.6.2: /etc/motd ---
check_file "MOTD Banner" "$MOTD_FILE" "true"

# --- Audit 1.6.3: /etc/issue.net ---
check_file "Remote Banner" "$ISSUE_NET_FILE" "true"

# Audit 1.6.3: Check SSHD Config
if grep -qE "^\s*Banner\s+$ISSUE_NET_FILE" "$SSHD_CONFIG"; then
    settings+=("{\"file\": \"$SSHD_CONFIG\", \"name\": \"SSHD Banner Config\", \"status\": \"Compliant\", \"value\": \"Banner $ISSUE_NET_FILE\"}")
else
    settings+=("{\"file\": \"$SSHD_CONFIG\", \"name\": \"SSHD Banner Config\", \"status\": \"Non-Compliant (Not set)\", \"value\": \"null\"}")
    AUDIT_STATUS="Non-Compliant"
fi


# --- Build Final JSON ---
JSON_SETTINGS=$(IFS=,; echo "${settings[*]}")

JSON_OUTPUT=$(cat <<EOF
{
  "auditDetails": {
    "benchmarkId": "1.6.2 & 1.6.3",
    "title": "Warning Banners (motd & issue.net)",
    "timestamp": "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  },
  "systemState": {
    "status": "$AUDIT_STATUS",
    "settings": [
      $JSON_SETTINGS
    ]
  }
}
EOF
)

# Save the JSON to the specified file
echo "$JSON_OUTPUT" > "$OUTPUT_FILE"

echo "Audit complete. Report saved to $OUTPUT_FILE"
