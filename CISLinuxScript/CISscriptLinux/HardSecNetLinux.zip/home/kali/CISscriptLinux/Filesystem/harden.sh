#!/bin/bash

# ---
# HARDEN Script for Warning Banners
# Benchmarks:
#   - 1.6.2: Configure /etc/motd
#   - 1.6.3: Configure /etc/issue.net and SSH
# ---

echo "Applying Warning Banner Hardening (1.6.2 & 1.6.3)..."

# --- Define Files ---
MOTD_FILE="/etc/motd"
ISSUE_NET_FILE="/etc/issue.net"
SSHD_CONFIG="/etc/ssh/sshd_config"

# --- Define Banner Text ---
read -r -d '' BANNER_TEXT << 'EOM'
*******************************************************************************
* This system is for the use of authorized users only. Activities on this     *
* system are monitored and recorded. Anyone using this system expressly       *
* consents to such monitoring and is advised that if it reveals possible      *
* evidence of criminal activity, system personnel may provide the evidence    *
* of such monitoring to law enforcement officials.                            *
*******************************************************************************
EOM

# --- Apply 1.6.2: /etc/motd ---
echo "Configuring $MOTD_FILE..."
echo "$BANNER_TEXT" > "$MOTD_FILE"
chown root:root "$MOTD_FILE"
chmod 644 "$MOTD_FILE"

# --- Apply 1.6.3: /etc/issue.net & SSH ---
echo "Configuring $ISSUE_NET_FILE..."
echo "$BANNER_TEXT" > "$ISSUE_NET_FILE"
chown root:root "$ISSUE_NET_FILE"
chmod 644 "$ISSUE_NET_FILE"

echo "Configuring $SSHD_CONFIG to use banner..."
# Remove any existing Banner or #Banner line and add the correct one
sed -i -E 's/^\s*#?\s*Banner\s+.*//' "$SSHD_CONFIG"
echo "Banner $ISSUE_NET_FILE" >> "$SSHD_CONFIG"

echo "Restarting SSH service..."
# Use the robust restart logic
if command -v systemctl &> /dev/null; then
    if systemctl list-units --type=service --all | grep -q 'ssh.service'; then
        echo "Found 'ssh.service', restarting..."
        systemctl restart ssh.service
    elif systemctl list-units --type=service --all | grep -q 'sshd.service'; then
        echo "Found 'sshd.service', restarting..."
        systemctl restart sshd.service
    else
        echo "Could not find 'ssh.service' or 'sshd.service'. Please restart SSH manually."
    fi
else
    echo "Could not find 'systemctl'. Please restart SSH manually."
fi

echo "--- Warning Banner Hardening Complete ---"
