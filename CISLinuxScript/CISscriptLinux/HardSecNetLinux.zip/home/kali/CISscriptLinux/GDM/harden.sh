#!/bin/bash

# ---
# CIS Benchmark: 1.7.6 Ensure GDM automatic mounting of removable media is disabled
# Category: GDM
# Description: Disables automounting and auto-opening of removable media
#              for all users by setting a system-wide dconf profile.
# ---

echo "Applying CIS 1.7.6: Disabling automatic mounting of removable media..."

# 1. Define paths for system-wide dconf settings
DB_DIR="/etc/dconf/db/local.d"
LOCK_DIR="/etc/dconf/db/local.d/locks"

# 2. Define the name for our settings and lock files
SETTINGS_FILE_NAME="10-cis-automount"
SETTINGS_FILE_PATH="$DB_DIR/$SETTINGS_FILE_NAME"
LOCK_FILE_PATH="$LOCK_DIR/$SETTINGS_FILE_NAME"

# 3. Ensure the directories exist
echo "Ensuring dconf directories exist..."
mkdir -p "$DB_DIR"
mkdir -p "$LOCK_DIR"

# 4. Create the settings file to set the default
echo "Creating dconf settings file: $SETTINGS_FILE_PATH"
cat > "$SETTINGS_FILE_PATH" << EOF
[org/gnome/desktop/media-handling]
# Disable automatic mounting of media
automount=false
# Disable opening a folder after mount
automount-open=false
EOF

# 5. Create the lock file to prevent users from changing it
echo "Creating dconf lock file: $LOCK_FILE_PATH"
cat > "$LOCK_FILE_PATH" << EOF
# Lock automount settings per CIS 1.7.6
/org/gnome/desktop/media-handling/automount
/org/gnome/desktop/media-handling/automount-open
EOF

# 6. Update the system-wide dconf database to apply the changes
echo "Updating system dconf database..."
dconf update

echo "---"
echo "CIS 1.7.6 hardening complete."
echo "!! IMPORTANT: You must LOG OUT and LOG BACK IN for this change to take effect."
echo "After logging in, insert a USB drive to verify it does not automount."
echo "---"
