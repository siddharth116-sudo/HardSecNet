#!/bin/bash

# ---
# HARDENING Script for CIS 3.1.2
#
# This script disables all wireless interfaces by running 'rfkill block all'.
# ---

echo "Applying CIS 3.1.2: Disabling all wireless interfaces..."

# 1. Install rfkill if it's not already installed
if ! command -v rfkill &> /dev/null; then
    echo "rfkill command not found. Installing..."
    apt-get update
    apt-get install -y rfkill
else
    echo "rfkill is already installed."
fi

# 2. Block all wireless devices (WLAN, Bluetooth, WWAN, etc.)
echo "Blocking all wireless devices (soft block)..."
rfkill block all

echo "---"
echo "CIS 3.1.2 hardening complete."
echo "All wireless devices have been soft blocked."
echo "Run 'rfkill list all' to verify."
echo "---"
